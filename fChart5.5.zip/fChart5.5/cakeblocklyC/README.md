Cake Core [![Stories in Ready](https://badge.waffle.io/cra16/cake-core.svg?label=ready&title=Ready)](http://waffle.io/cra16/cake-core) [![Code Climate](https://codeclimate.com/github/cra16/cake-core/badges/gpa.svg)](https://codeclimate.com/github/cra16/cake-core)
=====
