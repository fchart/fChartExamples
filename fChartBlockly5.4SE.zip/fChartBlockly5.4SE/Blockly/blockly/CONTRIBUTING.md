# Contributing to Blockly

Please make pull requests against develop, not master.  If your patch needs to go into master immediately, include a note in your PR.

For more information, head over to the [Blockly Developers site](https://developers.google.com/blockly/guides/modify/contributing).
